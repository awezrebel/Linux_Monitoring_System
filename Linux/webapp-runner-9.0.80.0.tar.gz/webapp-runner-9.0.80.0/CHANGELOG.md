# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## [9.0.80.0] - 2023-10-06

### Changed

- Update Tomcat to version `9.0.80`. ([#356](https://github.com/heroku/webapp-runner/pull/356))

[unreleased]: https://github.com/heroku/webapp-runner/compare/9.0.80.0...HEAD
[9.0.80.0]: https://github.com/heroku/webapp-runner/compare/9.0.78.0...9.0.80.0
